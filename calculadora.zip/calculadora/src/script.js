function calculate() {
    const weight = parseFloat(document.getElementById('weight').value);
    const height = parseFloat(document.getElementById('height').value);
    const age = parseInt(document.getElementById('age').value);
    const activity = parseFloat(document.getElementById('activity').value);
    const sex = document.getElementById('sex').value;
    const goal = document.getElementById('goal').value;

    // Verifica se todos os campos foram preenchidos
    if (isNaN(weight) || isNaN(height) || isNaN(age) || isNaN(activity) || !sex || !goal) {
        document.getElementById('result').textContent = 'Por favor, preencha todos os campos.';
        return;
    }

    // Cálculo da Taxa Metabólica Basal (TMB)
    let tmb;
    if (sex === 'male') {
        tmb = 66 + (13.7 * weight) + (5 * height) - (6.8 * age);
    } else {
        tmb = 655 + (9.6 * weight) + (1.8 * height) - (4.7 * age);
    }

    // Cálculo do Gasto Energético Total (GET)
    const get = tmb * activity;

    // Calcular a ingestão de calorias com base no objetivo
    let calorieIntake;
    switch (goal) {
        case 'lose':
            calorieIntake = get - 500; // Reduzir 500 kcal para perda de peso
            break;
        case 'maintain':
            calorieIntake = get; // Manter as calorias
            break;
        case 'gain':
            calorieIntake = get + 500; // Aumentar 500 kcal para ganho de massa
            break;
    }

    // Cálculo da ingestão de água e proteína
    const waterIntake = weight * 0.035; // Água em litros
    const proteinIntake = weight * 1.6; // Proteína em gramas

    // Cálculo da zona de queima de gordura
    const fatBurnLower = Math.round((220 - age) * 0.6);
    const fatBurnUpper = Math.round((220 - age) * 0.7);

    // Exibir os resultados na tela
    document.getElementById('tmb-result').textContent = `TMB: ${tmb.toFixed(2)} kcal/dia`;
    document.getElementById('get-result').textContent = `GET: ${get.toFixed(2)} kcal/dia`;
    document.getElementById('calories-result').textContent = `Sugestão de Ingestão Calórica: ${calorieIntake.toFixed(2)} kcal/dia`;
    document.getElementById('water-result').textContent = `Ingestão de Água: ${waterIntake.toFixed(2)} L/dia`;
    document.getElementById('protein-result').textContent = `Ingestão de Proteína: ${proteinIntake.toFixed(2)} g/dia`;
    document.getElementById('fatburn-result').textContent = `Zona de Queima de Gordura: ${fatBurnLower}-${fatBurnUpper} bpm`;
   // Adicionando classe para mostrar os resultados com animação
    const resultDiv = document.getElementById('result');
    resultDiv.classList.add('show'); // Adiciona a classe 'show' para animação
  // Esconde o spinner após os cálculos
        loadingSpinner.style.display = ('none');1000;
}
